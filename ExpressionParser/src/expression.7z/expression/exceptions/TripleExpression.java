package expression.exceptions;

/**
 * Created by aydar on 04.04.16.
 */
public interface TripleExpression {
    int evaluate(int x, int y, int z);
}
