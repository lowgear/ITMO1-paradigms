package expression.exceptions;

/**
 * Created by aydar on 18.04.16.
 */
public class ParseException extends RuntimeException {
    public ParseException(String message) {
        super(message);
    }
}
