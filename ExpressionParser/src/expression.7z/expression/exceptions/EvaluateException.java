package expression.exceptions;

/**
 * Created by aydar on 18.04.16.
 */
public class EvaluateException extends RuntimeException {
    public EvaluateException(String message) {
        super(message);
    }
}
